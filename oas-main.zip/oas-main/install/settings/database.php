<?php

/* settings/database.php */

return array(
    'mysql' => array(
        'dbdriver' => 'mysql',
        'username' => 'root',
        'password' => '',
        'dbname' => 'account',
        'prefix' => 'app',
    ),
    'tables' => array(
    ),
);
